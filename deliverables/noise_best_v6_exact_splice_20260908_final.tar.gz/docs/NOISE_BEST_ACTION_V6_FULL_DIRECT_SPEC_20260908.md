# Noise best-action V6 full direct fine-tuning specification

Date: 2026-09-08

## Immutable diagnosis of job 2333096

Job 2333096 completed; it did not crash.  It preserved all 32,114
numerically stable strict Top-1 action rows and therefore fixed the earlier
action-input outage.  The scientific result nevertheless failed:

- targeted versus initial E8 Recall@1: `+0.120002 pp`, formula-cluster CI
  `[-0.020440, +0.263916] pp`, 68 corrected and 46 introduced;
- targeted versus shuffled Recall@1: `-0.027273 pp`, 31 corrected and 36
  introduced;
- micro-candidate AUPRC versus E8: `-0.025065 pp`;
- all-adduct 10-ppm pooled pairwise AUROC versus E8: `-0.325679 pp`;
- `[M+H]+` 10-ppm pooled pairwise AUROC versus E8: `-0.360880 pp`;
- every promotion gate was false.

The 99.57% targeted action-view pass rate is not a learned result.  Those rows
were admitted precisely because the frozen E8 action view was already strict
Top-1.  The deployed clean view passed only 37.56% of its training boundaries.
Thus action materialization succeeded while clean-embedding transfer failed.

The failed run connected the best action bank to the old E4 symmetric cosine
interface.  It optimized each four-action physical batch immediately, used a
fixed 0.16 pre-scale followed by action weights and a success gate, and had no
candidate-boundary transfer branch.  This made repeated correlated views easy
to overwrite and did not directly encode the positive-versus-hard-negative
margin that made an action useful.  It was the wrong injection interface for
the right action bank.

## Numeric truth boundary

The current corrected-graph `+5.334988 pp` number is `3483 / 65286` before the
numerical replay floor.  After excluding the single numerical-boundary query,
the registered input is `3482 / 65286 = 5.333456 pp`.  Both numbers are the
fraction of outer-train queries having at least one materialized action that is
strict Top-1 in the frozen E8 geometry.  They are direct-action training
capacity, not a learned checkpoint result or a held-test promise.

The older `+4.929934 pp` number was also an action-oracle union on an already
consumed 5,923-query historical fold.  The best historical shared clean
encoder result was approximately `+0.6352 pp` on a now-retired candidate graph.
No prior checkpoint has established a 4--5 pp clean-embedding gain on the
current corrected graph.

V6 therefore retains 4 pp as a strict promotion gate.  It does not relabel
action headroom as model performance or claim that code can guarantee the
gate.

The single formal run is registered at seed `20260908`; a different seed is a
new replication and cannot be labelled as this formal V6 result.

## Frozen best-action input

V6 reuses, without re-mining, the immutable ledger from:

```text
data/validation/noise_corrected_best_v5_canary_fold_0_run_2332784/ledger
```

The preflight requires exactly:

- 327,678 routed rows: 62,430 corrective, 85,959 harmful and 179,289 robust;
- all seven executable sources: `N_mature`, `P_guided_original`, `E10B`,
  `E11`, `E12B`, `A4_exact` and `V4_gradient_path`;
- 32,127 strict Top-1 corrective rows before the frozen numerical margin
  floor;
- 32,114 rows and 3,482 unique queries after the `5e-6` floor;
- every admitted strict action retained; no one-best-per-query compression;
- common current-E8 clean ranks and zero cross-route clean-rank disagreement.

The formal entrypoint additionally pins the exact files, not merely their
names or counts:

- ledger report SHA-256 `246e7e871e6669fec9f2c62330a69bf9eb563a1b97b72b89732cecd682844349`;
- action CSV SHA-256 `93f0785a69b5e323490a0b543059fa213fabb6ff848697831efba5b3fed667aa`;
- action NPZ SHA-256 `6d57615aebbfb7bd6327bb7edb143c6837d2586221c61aa2ff45e833f5e1512a`;
- candidate graph/report SHA-256 `8a57bb3a9cccdf69a738f2b093bfad8f6fc4393b23f1342c7a035ac54ce58fa1`
  and `1a69db8f14d271adfa454900a206b5bc3cc4d1c51e91703e499ca74837bf557f`;
- E8 initialization SHA-256 `8047b3f58c6808c86b320ac94b9e610610384040fa3a03e8d70550eb438a24af`;
- official checkpoint SHA-256 `8928f908606c0bd652c5a4107d3c35102f660622958c225a1f625abe4b1ba245`;
- MassSpecGym HDF5 SHA-256 `ccda2c4114d9b21413977df03376ca0fc097956a7fa304b861a3154a2b81e64f`;
- raw architecture checkpoint SHA-256 `9884b62ecadf4bd441d22fec79b6787e5ffef168e15e7d8d5804dbdea08b38b2`.

The allocated job also checks byte-exact SHA-256 values for the selector, the
registered V3 trainer and objective stack (including the actual `hard_cap`
implementation and its import chain), the causal shuffle, evaluator,
summarizer and formal tests before loading the model.  The compact admitted-ID
and semantic-boundary hashes are deterministic derivatives of those pinned
inputs and sources; every arm records them and the final summarizer requires
exact cross-arm equality.

E4 is the direct shared-training foundation and E8 is the initialization; they
are not omitted spectrum-action sources.  E13 reused E12B and contributes no
new action bank.  E14's failed trainer is not reused.

## V6 direct injection contract

V6 changes no scientific route and uses no teacher embedding or distillation
target.  It trains the shared DreaMS encoder directly from clean, real action,
matched-control and candidate spectra.

1. **Strict corrective admission.** Only frozen outer-train rows with clean
   rank not equal to one, action rank equal to one and action margin above
   `5e-6` carry the corrective gradient.  Harmful and robust rows remain in
   their separate safety branches.
2. **Admission precedes every control transform.** The 32,114 corrective rows
   are combined with all 85,959 harmful and 179,289 robust rows, giving one
   297,362-row admitted table.  Action and paired-control tensors are subset by
   the identical original index vector and then continuously reindexed.  Only
   after this operation may the shuffled arm choose donors.  Therefore a
   rejected corrective row, held row or query-limited row cannot become a
   shuffled donor.
3. **Query-complete aggregation.** Every selected action for one query is
   encoded in the same `BoundaryExample`; the query receives one aggregated
   optimizer contribution.  Action multiplicity cannot create extra optimizer
   steps.
4. **Candidate-relative transfer.** The existing v3 objective transfers the
   bounded action-versus-clean and action-versus-control improvement on the
   union of clean/action/control hard candidate boundaries.  Targets are
   detached scalars, while clean query and live shared candidate references
   remain trainable.  This preserves the empirically superior E8 shared
   geometry and is direct margin supervision, not embedding imitation.
5. **Registered V3 transfer allocation unchanged.** The allocator remains
   `hard_cap`, exactly as in the signal-tested V3 injector.  The later
   `mass_neutral_monotone` proposal is excluded because it has only local
   tensor evidence and would introduce a second scientific change.
6. **Post-shuffle actual-bank calibration.** Each arm is calibrated on the
   exact action bank it will use in optimization.  Routed and clean therefore
   calibrate on the admitted targeted bank; shuffled calibrates after the
   admitted bank has been shuffled.  Coefficients may differ, but each active
   arm must independently hit the same registered branch and dense
   corrective-to-protect gradient ratios without a scale cap.  Reusing routed
   coefficients on shuffled data is forbidden because it does not equalize
   realized optimizer dose.
7. **Low-loss safety path.** Corrective, robust, harmful and full clean-protect
   gradients remain separate through calibration.  Auxiliary gradients are
   projected so they cannot erase corrective direction, the combined action
   gradient is projected against clean risk, and post-PCGrad/clip plus realized
   AdamW attribution are recorded separately for head and backbone.
8. **Full coverage.** Four registered epochs use the complete 65,286-query
   fold-0 outer-train clean graph.  Evaluation uses all 18,333 formula-held
   queries.  There are no development query limits.
9. **Fail-closed forward-memory bound.** A query is never split or truncated.
   Before calibration, the trainer calculates the exact number of spectrum
   views required by every query-complete logical batch and refuses any batch
   above 512 views.  The bound only prevents an OOM-prone forward; it does not
   rescale, repack or change the V3 loss.

The selective query-only stop-gradient idea is deliberately excluded.  The
historical E8 factor experiment found fixed candidate references about
0.2195 pp worse than shared current references, and no held result establishes
that a selective stop-gradient improves this route.

## Causal arms and server execution

The formal job runs one complete seed (`20260908`):

- routed best actions on GPU 0;
- exact-stratum shuffled actions concurrently on GPU 1;
- matched clean continuation on GPU 0 after both action arms finish.

All three arms start from the same E8 checkpoint and use the same query
schedule, clean protection, optimizer budget and seed.  Routed and shuffled
are independently calibrated on their actual post-transform banks to the same
registered realized gradient-ratio targets.
The first action-arm failure terminates the peer immediately.  Outputs are
written to a unique staging directory and moved atomically only after complete
evaluation.

The job requests exactly two GPUs and no manual memory allocation.  Python
tests and preflight run inside the Slurm allocation.  Nothing in this protocol
authorizes Python execution on the login node.

Manual submission from the server repository root is exactly:

```bash
sbatch tasks/run_noise_corrected_best_v6_full_2gpu.sbatch
```

## Simultaneous metric and promotion gate

On the identical 18,333-query clean-input held graph, the summary reports:

- Recall@1/2/3/5/10/20;
- MRR and mean/median rank;
- macro-query AUROC/AUPRC;
- micro-candidate AUROC/AUPRC;
- positive-versus-best-negative margin and signed/unsigned Top1--Top2 gap;
- corrected, introduced and risk-net (`corrected - 2 * introduced`);
- the same retrieval, margin and risk outcomes on the near subset;
- multiplicity-corrected formula-cluster paired confidence intervals;
- MassSpecGym all-adduct and `[M+H]+` 10-ppm pooled pairwise AUROC/AUPRC.

The MassSpecGym pooled value is not labelled an exact NIST20 paper-0.85
replication.  Promotion requires at least `+4.0 pp` Recall@1 versus the exact
initial E8 checkpoint, routed superiority over both shuffled and clean arms,
strictly positive paired formula-cluster CI lower bounds, positive overall and
near risk-net, no regression across the registered metric family, and every
signal-transmission/configuration gate passing.  A non-promoted result remains
an immutable result and is never silently reinterpreted as success.

"""Static submission contract for the full best-action v6 Slurm job."""
from __future__ import annotations

from pathlib import Path


SBATCH = Path(__file__).with_name("run_noise_corrected_best_v6_full_2gpu.sbatch")


def test_resource_contract_is_exactly_two_gpus_without_manual_memory() -> None:
    text = SBATCH.read_text(encoding="utf-8")
    directives = [line.strip() for line in text.splitlines() if line.startswith("#SBATCH")]
    assert directives.count("#SBATCH --gpus=2") == 1
    assert not any("--mem" in line for line in directives)
    assert "#SBATCH --cpus-per-task=16" in directives
    assert "srun " not in text


def test_formal_training_uses_the_repaired_v3_interface_and_no_query_limits() -> None:
    text = SBATCH.read_text(encoding="utf-8")
    common = text.split("COMMON=(", 1)[1].split("\n)", 1)[0]
    assert "--corrective-objective-mode v3_direct" in common
    assert "--direct-contract best_action_v6" in common
    assert "--corrective-admission strict_top1" in common
    assert "--corrective-margin-floor 0.000005" in common
    assert "--no-arm-invariant-targeted-calibration" in common
    assert "--transfer-target-allocation hard_cap" in common
    assert "--maximum-spectra-per-action-forward 512" in common
    assert "--epochs 4" in common
    assert "--reference-refresh-every-epochs 1" in common
    assert "--bootstrap-resamples 10000" in common
    assert "--development" not in common
    assert "--maximum-corrective-queries" not in common
    assert "--maximum-risk-queries" not in common
    assert "--maximum-robust-queries" not in common
    assert "--maximum-clean-queries" not in common
    assert "--outer-held-eval-queries" not in common
    assert "python -u tasks/train_noise_final_e4a_direct_augmentation.py" not in text


def test_immutable_action_bank_and_three_causal_arms_are_fail_closed() -> None:
    text = SBATCH.read_text(encoding="utf-8")
    assert "noise_corrected_best_v5_canary_fold_0_run_2332784" in text
    assert "SOURCE_RUN=\"${SOURCE_RUN:-" not in text
    for digest in (
        "ccda2c4114d9b21413977df03376ca0fc097956a7fa304b861a3154a2b81e64f",
        "9884b62ecadf4bd441d22fec79b6787e5ffef168e15e7d8d5804dbdea08b38b2",
        "93f0785a69b5e323490a0b543059fa213fabb6ff848697831efba5b3fed667aa",
        "246e7e871e6669fec9f2c62330a69bf9eb563a1b97b72b89732cecd682844349",
        "6d57615aebbfb7bd6327bb7edb143c6837d2586221c61aa2ff45e833f5e1512a",
    ):
        assert digest in text
    assert "len(selected) == 32114" in text
    assert "selected.query_index.nunique() == 3482" in text
    assert "== set(actions.source.astype(str))" in text
    assert "== 297362" in text
    assert 'run_arm "$GPU_ZERO" routed_direct &' in text
    assert 'run_arm "$GPU_ONE" shuffled_action_control &' in text
    assert 'run_arm "$GPU_ZERO" clean_control' in text
    assert 'wait -n "$PID_ROUTED" "$PID_SHUFFLED"' in text
    assert "summarize_noise_corrected_direct_v3_arms.py" in text
    assert '"registered_formal_direct_configuration_verified"' in text
    assert 'SOURCE_SNAPSHOT="$RUN_ROOT/source_snapshot"' in text
    assert 'sha256sum "$SOURCE_SNAPSHOT"/*' in text
    assert "sha256sum -c <<'SOURCE_SHA256'" in text
    for dependency in (
        "audit_noise_peak_gate_candidate_injection.py",
        "noise_final_core.py",
        "noise_final_direct_boundary_v2_core.py",
        "noise_corrected_transfer_objective_v4.py",
        "noise_corrected_action_expansion_v4.py",
        "noise_v3_core.py",
        "noise_corrected_action_routing_v3.py",
        "noise_corrected_directional_update_v4.py",
        "noise_corrected_update_arbitration_v4.py",
        "noise_final_e15_core.py",
        "train_e1_identity.py",
        "train_noise_final_e4a_direct_augmentation.py",
        "train_noise_final_r2_shared_encoder.py",
    ):
        assert f"tasks/{dependency}" in text


def test_all_python_preflight_executes_inside_the_allocated_sbatch() -> None:
    text = SBATCH.read_text(encoding="utf-8")
    assert text.startswith("#!/bin/bash\n#SBATCH")
    assert "python -u tasks/test_noise_corrected_best_action_v6.py" in text
    assert "python -u tasks/test_summarize_noise_corrected_direct_v3_arms.py" in text
    assert "python -u tasks/test_noise_corrected_best_v6_sbatch.py" in text
    assert "teacher_embedding_or_distillation_target_used" in text


def main() -> None:
    tests = [
        test_resource_contract_is_exactly_two_gpus_without_manual_memory,
        test_formal_training_uses_the_repaired_v3_interface_and_no_query_limits,
        test_immutable_action_bank_and_three_causal_arms_are_fail_closed,
        test_all_python_preflight_executes_inside_the_allocated_sbatch,
    ]
    for test in tests:
        test()
    print(f"[test_noise_corrected_best_v6_sbatch] PASS tests={len(tests)}")


if __name__ == "__main__":
    main()

# CALMS v1.0 compact evidence bundle

This deterministic archive contains the executable frozen CALMS v1.0 release,
the 2026-11-05 package/application, consumed-GNPS and mechanism result records,
their exact summary and diagnostic scripts, synthetic contract tests, and
compact reports/tables/plots.

Scientific boundary: GNPS was consumed during development and residual-scale
selection. These results are development evidence, not unopened external
confirmation or a field-wide SOTA claim.

The four per-query correction ledgers are intentionally excluded to keep this
archive compact. Re-running the full diagnostics therefore additionally
requires the original repository benchmark inputs and query ledgers. The
frozen inference package itself is executable from this archive.

From the archive root, install and validate frozen inference with:

    python -m pip install -r deploy/calms_v1/requirements-runtime.txt
    python deploy/calms_v1/test_calms_frozen_release.py
    python tasks/build_calms_manuscript_main_tables.py --evidence-root . --output reproduced_tables

Retain one synthetic end-to-end CLI example with:

    python deploy/calms_v1/examples/run_smoke.py --output-root calms_smoke

The analysis tests require numpy, pandas, scikit-learn and pytest and can be
run with `tasks` on `PYTHONPATH`.

All payload hashes are in `checksums.sha256`; `bundle_manifest.json` records
the exact inclusion and exclusion policy. Archive entry order, timestamps,
permissions and compression settings are fixed by
`tasks/build_calms_v1_evidence_bundle.py`.

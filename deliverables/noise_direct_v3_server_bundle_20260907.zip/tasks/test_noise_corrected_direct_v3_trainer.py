"""Focused invariants for direct-v3 trainer reference wiring."""
from __future__ import annotations

import numpy as np
import pandas as pd
import torch
from types import SimpleNamespace

from train_noise_corrected_routed_direct import (
    BoundaryExample,
    REGISTERED_V3_EXACT_CONFIGURATION,
    REGISTERED_V3_FLOAT_CONFIGURATION,
    RoutedAction,
    augment_action_conditioned_references,
    _bounded_calibration_scale,
    _bounded_dense_auxiliary_scale,
    _formula_stratified_batches,
    _finalize_transfer_edge_breakdown,
    _gradient_cosine,
    _gradient_direction_retention,
    _batch_cardinality_scale,
    _global_mechanism_weights,
    _interleaved_single_exposure_auxiliary_schedules,
    _identity_stratified_batches,
    _mechanism_block,
    _optimizer_parameter_group_positions,
    _preserve_corrective_against_auxiliary,
    _prioritize_mechanism_coverage,
    _single_exposure_auxiliary_schedule,
    _take_gradient_positions,
    _union_initial_negative_molecules,
    _validate_registered_formal_v3_configuration,
    _virtual_adamw_descent_updates,
    _weighted_mechanism_mass,
    select_references,
    select_references_from_pair_scores,
)


class TinyGraph:
    query_row = np.asarray([0], dtype=np.int64)

    def query_block(self, query: int):
        assert query == 0
        return (
            slice(0, 5),
            np.asarray([1, 2, 3, 4, 5], dtype=np.int64),
            np.asarray([0, 2, 4, 5], dtype=np.int64),
            0,
        )


def test_all_registered_sources_map_to_three_mechanisms() -> None:
    assert {
        source: _mechanism_block(source)
        for source in (
            "N_mature", "P_guided_original", "E10B", "E11", "E12B", "A4_exact",
        )
    } == {
        "N_mature": "N", "P_guided_original": "P", "E10B": "P",
        "E11": "P", "E12B": "P", "A4_exact": "A4",
    }


def test_vectorized_pair_score_reference_selection_matches_direct_dot() -> None:
    graph = TinyGraph()
    rows = np.arange(6, dtype=np.int64)
    embeddings = np.asarray([
        [1.0, 0.0],
        [0.9, 0.1],
        [0.8, 0.2],
        [0.7, 0.3],
        [0.2, 0.8],
        [0.6, 0.4],
    ], dtype=np.float32)
    embeddings /= np.linalg.norm(embeddings, axis=1, keepdims=True)
    index = {int(row): int(row) for row in rows}
    pair_scores = embeddings[[1, 2, 3, 4, 5]] @ embeddings[0]
    direct = select_references(
        graph, 0, embeddings, index, positives=2, negatives=2, per_negative=2,
    )
    cached = select_references_from_pair_scores(
        graph, 0, pair_scores, positives=2, negatives=2, per_negative=2,
    )
    assert direct == cached


def test_identity_stratified_batches_cover_once_and_spread_repeated_views() -> None:
    examples = [
        BoundaryExample(
            query_index=index,
            query_row=index,
            identity=("repeat" if index < 5 else f"id{index}"),
            formula=f"F{index}",
            actions=(),
            positive_rows=(1,),
            negative_rows=((2,),),
        )
        for index in range(12)
    ]
    batches = _identity_stratified_batches(
        examples, 4, np.random.default_rng(9),
    )
    flattened = [example for batch in batches for example in batch]
    assert sorted(example.query_index for example in flattened) == list(range(12))
    # While at least four identities remain, no batch needs two views from the
    # repeated identity.
    assert all(
        sum(example.identity == "repeat" for example in batch) <= 1
        for batch in batches[:2]
    )


def test_formula_stratified_calibration_batches_are_formula_diverse() -> None:
    examples = [
        BoundaryExample(
            query_index=index,
            query_row=index,
            identity=f"id{index}",
            formula=f"F{index % 5}",
            actions=(),
            positive_rows=(1,),
            negative_rows=((2,),),
        )
        for index in range(15)
    ]
    batches = _formula_stratified_batches(
        examples, 4, np.random.default_rng(19),
    )
    assert sorted(
        example.query_index for batch in batches for example in batch
    ) == list(range(15))
    assert all(
        len({example.formula for example in batch}) == len(batch)
        for batch in batches
    )


def test_global_mechanism_weights_cancel_cross_query_p_coverage() -> None:
    actions = pd.DataFrame([
        {"query_index": 0, "source": "N_mature"},
        {"query_index": 0, "source": "E10B"},
        {"query_index": 1, "source": "E11"},
        {"query_index": 1, "source": "A4_exact"},
        {"query_index": 2, "source": "E12B"},
    ])
    coefficients, report = _global_mechanism_weights(
        actions, {0: 1.0, 1: 1.0, 2: 1.0},
    )
    assert report["balanced"] is True
    assert np.isclose(coefficients["P"], 1 / 3)
    assert np.isclose(coefficients["N"], 1.0)
    assert np.isclose(coefficients["A4"], 1.0)
    assert np.allclose(list(report["effective_epoch_mass"].values()), 1.0)


def test_calibration_prefix_prioritizes_rare_mechanisms_without_rebatching() -> None:
    def example(index: int, mechanism: str) -> BoundaryExample:
        source = {"N": "N_mature", "P": "E10B", "A4": "A4_exact"}[mechanism]
        return BoundaryExample(
            query_index=index,
            query_row=index,
            identity=f"id{index}",
            formula=f"F{index}",
            actions=(RoutedAction(
                f"a{index}", index, f"{mechanism}::{source}|family",
            ),),
            positive_rows=(1,),
            negative_rows=((2,),),
        )
    batches = [
        [example(0, "P")],
        [example(1, "P")],
        [example(2, "P")],
        [example(3, "N")],
        [example(4, "A4")],
    ]
    prioritized = _prioritize_mechanism_coverage(batches)
    first_three = {
        action.group.split("::", 1)[0]
        for batch in prioritized[:3]
        for item in batch for action in item.actions
    }
    assert first_three == {"N", "P", "A4"}
    assert {id(batch) for batch in prioritized} == {id(batch) for batch in batches}


def test_actual_schedule_mass_preserves_global_mechanism_balance() -> None:
    def example(index: int, mechanisms: tuple[str, ...]) -> BoundaryExample:
        coefficients = {"P": 1 / 3, "N": 1.0, "A4": 1.0}
        sources = {"P": "E10B", "N": "N_mature", "A4": "A4_exact"}
        return BoundaryExample(
            query_index=index,
            query_row=index,
            identity=f"id{index}",
            formula=f"F{index}",
            actions=tuple(
                RoutedAction(
                    f"{mechanism}{index}", index,
                    f"{mechanism}::{sources[mechanism]}|family",
                    mechanism_weight=coefficients[mechanism],
                )
                for mechanism in mechanisms
            ),
            positive_rows=(1,), negative_rows=((2,),), epoch_weight=1.0,
        )
    examples = [
        example(0, ("N", "P")),
        example(1, ("A4", "P")),
        example(2, ("P",)),
    ]
    mass = _weighted_mechanism_mass(examples, scale=2.0)
    assert np.allclose([mass["N"], mass["P"], mass["A4"]], 2.0)


def test_sparse_auxiliary_schedule_is_single_exposure_without_duty_amplification() -> None:
    batches = [[object()], [object()], [object()]]
    schedule = _single_exposure_auxiliary_schedule(
        batches, 17, np.random.default_rng(29),
    )
    flattened = [batch for step in schedule for batch in step]
    assert len(schedule) == 17
    assert len(flattened) == len(batches)
    assert {id(batch) for batch in flattened} == {id(batch) for batch in batches}
    assert sum(bool(step) for step in schedule) == len(batches)
    active_positions = [index for index, step in enumerate(schedule) if step]
    assert active_positions != list(range(len(batches)))
    assert max(active_positions) - min(active_positions) >= 17 // len(batches)


def test_sparse_semantic_panels_are_interleaved_without_avoidable_overlap() -> None:
    robust = [[object()] for _ in range(3)]
    harmful = [[object()] for _ in range(2)]
    schedules = _interleaved_single_exposure_auxiliary_schedules(
        {"robust": robust, "harmful": harmful},
        17,
        np.random.default_rng(31),
    )
    combined = [
        len(schedules["robust"][index]) + len(schedules["harmful"][index])
        for index in range(17)
    ]
    assert max(combined) == 1
    assert sum(bool(value) for value in combined) == 5
    for name, original in (("robust", robust), ("harmful", harmful)):
        flattened = [batch for step in schedules[name] for batch in step]
        assert {id(batch) for batch in flattened} == {id(batch) for batch in original}


def test_dense_semantic_panels_keep_coverage_bounded_load_and_bounded_mass() -> None:
    for robust_count, harmful_count, corrective_steps in (
        (10, 7, 3), (21, 3, 5), (8, 8, 4), (1, 1, 1),
    ):
        robust = [[object()] for _ in range(robust_count)]
        harmful = [[object()] for _ in range(harmful_count)]
        steps = max(corrective_steps, int(np.ceil(
            (robust_count + harmful_count) / 4,
        )))
        schedules = _interleaved_single_exposure_auxiliary_schedules(
            {"robust": robust, "harmful": harmful},
            steps,
            np.random.default_rng(37),
        )
        combined = [
            len(schedules["robust"][index])
            + len(schedules["harmful"][index])
            for index in range(steps)
        ]
        assert max(combined) <= 4
        assert max(combined) - min(combined) <= 1
        for name, batches in (("robust", robust), ("harmful", harmful)):
            flattened = [batch for step in schedules[name] for batch in step]
            assert {id(batch) for batch in flattened} == {id(batch) for batch in batches}
            assert len(flattened) == len(batches)
            scale = _bounded_dense_auxiliary_scale(len(batches), steps)
            assert np.isclose(scale * len(batches), min(len(batches), steps))


def test_partial_batch_mean_is_scaled_to_registered_query_mass() -> None:
    assert np.isclose(_batch_cardinality_scale([1, 2, 3, 4], 4), 1.0)
    assert np.isclose(_batch_cardinality_scale([1], 4), 0.25)
    try:
        _batch_cardinality_scale([1, 2, 3, 4, 5], 4)
    except ValueError:
        pass
    else:
        raise AssertionError("oversized batch passed registered cardinality gate")


def test_transfer_edge_breakdown_uses_pooled_counts_not_batch_means() -> None:
    report = _finalize_transfer_edge_breakdown({
        "all": {
            "considered": 10,
            "action_better_clean": 5,
            "action_better_control": 4,
            "active": 3,
            "clean_limited": 6,
            "control_limited": 4,
            "capped": 2,
        },
        "family=projection": {
            "considered": 4,
            "active": 1,
        },
    })
    assert report["all"]["active"] == 3
    assert np.isclose(report["all"]["active_fraction"], 0.3)
    assert np.isclose(report["family=projection"]["active_fraction"], 0.25)


def test_calibration_caps_fail_closed_instead_of_silently_underdosing() -> None:
    value, truncated = _bounded_calibration_scale(
        3.0, 4.0, "test", require_exact=True,
    )
    assert value == 3.0 and truncated is False
    try:
        _bounded_calibration_scale(5.0, 4.0, "test", require_exact=True)
    except RuntimeError as error:
        assert "silently under-dosed" in str(error)
    else:
        raise AssertionError("active calibration silently accepted a truncated scale")
    value, truncated = _bounded_calibration_scale(
        5.0, 4.0, "inactive control", require_exact=False,
    )
    assert value == 4.0 and truncated is True


def test_reference_refresh_unions_molecules_without_duplicating_same_molecule() -> None:
    def example(negative_rows, positive_rows=(1, 2)):
        return BoundaryExample(
            query_index=0,
            query_row=0,
            identity="q",
            formula="F",
            actions=(),
            positive_rows=positive_rows,
            negative_rows=negative_rows,
        )

    initial = [example(((3,), (5,)))]
    # Row 4 is another spectrum from the same candidate molecule as row 3.
    current = [example(((4,),), positive_rows=(1,))]
    merged = _union_initial_negative_molecules(TinyGraph(), initial, current)
    assert merged[0].positive_rows == (1, 2)
    assert merged[0].negative_rows == ((4, 3), (5,))


def test_action_conditioned_reference_adds_exact_switch_with_shared_boundary() -> None:
    graph = TinyGraph()
    embeddings = np.asarray([
        [1.0, 0.0],
        [0.9, 0.1], [0.8, 0.2],
        [0.7, 0.3], [0.2, 0.8],
        [0.6, 0.4],
    ], dtype=np.float32)
    embeddings /= np.linalg.norm(embeddings, axis=1, keepdims=True)
    example = BoundaryExample(
        query_index=0,
        query_row=0,
        identity="q",
        formula="F",
        actions=(RoutedAction("a", 0, "N::N_mature|candidate"),),
        positive_rows=(1,),
        negative_rows=((5,),),
    )
    rows = pd.DataFrame([{
        "action_id": "a", "query_index": 0,
        "action_positive_row": 2,
        "action_hard_negative_molecule_index": 1,
        "action_hard_negative_row": 4,
        "control_positive_row": 1,
        "control_hard_negative_molecule_index": 2,
        "control_hard_negative_row": 5,
    }])
    augmented, report = augment_action_conditioned_references(
        graph, [example], rows, embeddings, {index: index for index in range(6)},
        maximum_positive_references=2,
        maximum_negative_molecules=2,
        references_per_negative=2,
    )
    assert augmented[0].positive_rows == (1, 2)
    assert augmented[0].negative_rows == ((5,), (4, 3))
    assert report["action_conditioned_candidate_switch_queries"] == 1


def test_action_conditioned_reference_merges_new_row_for_existing_molecule() -> None:
    graph = TinyGraph()
    embeddings = np.asarray([
        [1.0, 0.0],
        [0.9, 0.1], [0.8, 0.2],
        [0.7, 0.3], [0.2, 0.8],
        [0.6, 0.4],
    ], dtype=np.float32)
    embeddings /= np.linalg.norm(embeddings, axis=1, keepdims=True)
    example = BoundaryExample(
        query_index=0,
        query_row=0,
        identity="q",
        formula="F",
        actions=(RoutedAction("a", 0, "N::N_mature|candidate"),),
        positive_rows=(1,),
        # Molecule one is already present, but only through row three.
        negative_rows=((3,),),
    )
    rows = pd.DataFrame([{
        "action_id": "a", "query_index": 0,
        "action_positive_row": 2,
        "action_hard_negative_molecule_index": 1,
        "action_hard_negative_row": 4,
        "control_positive_row": 1,
        "control_hard_negative_molecule_index": 1,
        "control_hard_negative_row": 3,
    }])
    augmented, report = augment_action_conditioned_references(
        graph, [example], rows, embeddings, {index: index for index in range(6)},
        maximum_positive_references=2,
        maximum_negative_molecules=1,
        # The exact routed row must survive even when this ordinary clean-row
        # supplement limit is already full.
        references_per_negative=1,
    )
    assert augmented[0].positive_rows == (1, 2)
    assert augmented[0].negative_rows == ((3, 4),)
    assert report["action_conditioned_candidate_switch_queries"] == 1
    assert report["negative_molecules_added_maximum"] == 0
    assert report["negative_spectrum_rows_added_maximum"] == 1
    assert report["routed_hard_rows_never_truncated_within_molecule"] is True


def test_virtual_adamw_update_matches_real_optimizer_step() -> None:
    parameter = torch.nn.Parameter(torch.tensor([1.5, -0.5], dtype=torch.float64))
    optimizer = torch.optim.AdamW(
        [parameter], lr=0.01, betas=(0.8, 0.9), eps=1e-8, weight_decay=0.02,
    )
    for gradient in (
        torch.tensor([0.3, -0.4], dtype=torch.float64),
        torch.tensor([-0.2, 0.1], dtype=torch.float64),
    ):
        expected = _virtual_adamw_descent_updates(
            optimizer, [parameter], [gradient],
        )[0]
        before = parameter.detach().clone()
        parameter.grad = gradient.clone()
        optimizer.step()
        actual = before - parameter.detach()
        assert expected is not None
        assert torch.allclose(actual, expected, atol=1e-12, rtol=1e-10)
        optimizer.zero_grad(set_to_none=True)

    combined = _virtual_adamw_descent_updates(
        optimizer, [parameter], [torch.tensor([0.2, -0.3], dtype=torch.float64)],
    )[0]
    risk_only = _virtual_adamw_descent_updates(
        optimizer, [parameter], [torch.tensor([0.1, -0.1], dtype=torch.float64)],
    )[0]
    assert combined is not None and risk_only is not None
    assert float(torch.linalg.vector_norm(combined - risk_only)) > 0


def test_optimizer_parameter_groups_partition_action_gradient_ledger() -> None:
    head = torch.nn.Parameter(torch.tensor([1.0]))
    backbone = torch.nn.Parameter(torch.tensor([2.0, 3.0]))
    parameters = [backbone, head]
    optimizer = torch.optim.AdamW([
        {"params": [head], "group_name": "head"},
        {"params": [backbone], "group_name": "backbone"},
    ], lr=1e-3)
    positions = _optimizer_parameter_group_positions(optimizer, parameters)
    assert positions == {"head": [1], "backbone": [0]}
    gradients = [torch.tensor([0.2, 0.3]), torch.tensor([0.4])]
    assert _take_gradient_positions(gradients, positions["head"])[0] is gradients[1]
    assert _take_gradient_positions(gradients, positions["backbone"])[0] is gradients[0]


def test_inner_semantic_projection_cannot_erase_corrective_direction() -> None:
    corrective = [torch.tensor([1.0, 0.0])]
    auxiliary = [torch.tensor([-3.0, 4.0])]
    combined, projected_auxiliary, report = _preserve_corrective_against_auxiliary(
        corrective, auxiliary,
    )
    assert torch.allclose(projected_auxiliary[0], torch.tensor([0.0, 4.0]))
    assert torch.allclose(combined[0], torch.tensor([1.0, 4.0]))
    assert report["conflict"] is True
    assert report["corrective_direction_preserved"] is True
    assert np.isclose(report["corrective_direction_preservation_ratio"], 1.0)

    agreeing, kept, agreeing_report = _preserve_corrective_against_auxiliary(
        corrective, [torch.tensor([2.0, 3.0])],
    )
    assert torch.allclose(kept[0], torch.tensor([2.0, 3.0]))
    assert torch.allclose(agreeing[0], torch.tensor([3.0, 3.0]))
    assert agreeing_report["conflict"] is False
    assert agreeing_report["corrective_direction_preservation_ratio"] > 1.0

    grouped, grouped_auxiliary, grouped_report = (
        _preserve_corrective_against_auxiliary(
            [torch.tensor([1.0, 0.0]), torch.tensor([1.0, 0.0])],
            [torch.tensor([-2.0, 0.0]), torch.tensor([3.0, 0.0])],
            {"backbone": [0], "head": [1]},
        )
    )
    assert torch.allclose(grouped_auxiliary[0], torch.zeros(2))
    assert torch.allclose(grouped_auxiliary[1], torch.tensor([3.0, 0.0]))
    assert torch.allclose(grouped[0], torch.tensor([1.0, 0.0]))
    assert torch.allclose(grouped[1], torch.tensor([4.0, 0.0]))
    assert all(
        value["corrective_direction_preserved"]
        for value in grouped_report["parameter_groups"].values()
    )


def test_gradient_cosine_is_bounded_and_marks_inactive_branches() -> None:
    assert np.isclose(
        _gradient_cosine(
            [torch.tensor([1.0, 0.0]), None],
            [torch.tensor([0.5, 0.5]), None],
        ),
        1.0 / np.sqrt(2.0),
    )
    assert _gradient_cosine(
        [torch.zeros(2), None], [torch.ones(2), None],
    ) is None
    assert np.isclose(
        _gradient_direction_retention(
            [torch.tensor([0.2, 3.0])], [torch.tensor([1.0, 0.0])],
        ),
        0.2,
    )
    assert _gradient_direction_retention(
        [torch.ones(2)], [torch.zeros(2)],
    ) is None


def test_registered_formal_v3_configuration_fails_closed_on_drift() -> None:
    values = {
        **REGISTERED_V3_EXACT_CONFIGURATION,
        **REGISTERED_V3_FLOAT_CONFIGURATION,
        "development": False,
        "corrective_objective_mode": "v3_direct",
    }
    _validate_registered_formal_v3_configuration(SimpleNamespace(**values))
    values["grad_clip"] = 2.0
    try:
        _validate_registered_formal_v3_configuration(SimpleNamespace(**values))
    except RuntimeError as error:
        assert "grad_clip" in str(error)
    else:
        raise AssertionError("formal v3 accepted a rejected clip-2 configuration")
    values["development"] = True
    _validate_registered_formal_v3_configuration(SimpleNamespace(**values))
    truncated = {
        **REGISTERED_V3_EXACT_CONFIGURATION,
        **REGISTERED_V3_FLOAT_CONFIGURATION,
        "development": False,
        "corrective_objective_mode": "v3_direct",
        "maximum_clean_queries": 128,
    }
    try:
        _validate_registered_formal_v3_configuration(SimpleNamespace(**truncated))
    except RuntimeError as error:
        assert "maximum_clean_queries" in str(error)
    else:
        raise AssertionError("formal v3 accepted a development query truncation")


def test_dense_auxiliary_scale_preserves_sparse_mass_and_caps_dense_mass() -> None:
    assert _bounded_dense_auxiliary_scale(3, 8) == 1.0
    assert np.isclose(_bounded_dense_auxiliary_scale(10, 4), 0.4)
    assert np.isclose(10 * _bounded_dense_auxiliary_scale(10, 4), 4.0)
    for batches, steps in ((0, 4), (4, 0)):
        try:
            _bounded_dense_auxiliary_scale(batches, steps)
        except ValueError:
            pass
        else:
            raise AssertionError("invalid dense auxiliary scale was accepted")


def main() -> None:
    test_all_registered_sources_map_to_three_mechanisms()
    test_vectorized_pair_score_reference_selection_matches_direct_dot()
    test_identity_stratified_batches_cover_once_and_spread_repeated_views()
    test_formula_stratified_calibration_batches_are_formula_diverse()
    test_global_mechanism_weights_cancel_cross_query_p_coverage()
    test_calibration_prefix_prioritizes_rare_mechanisms_without_rebatching()
    test_actual_schedule_mass_preserves_global_mechanism_balance()
    test_sparse_auxiliary_schedule_is_single_exposure_without_duty_amplification()
    test_sparse_semantic_panels_are_interleaved_without_avoidable_overlap()
    test_dense_semantic_panels_keep_coverage_bounded_load_and_bounded_mass()
    test_partial_batch_mean_is_scaled_to_registered_query_mass()
    test_transfer_edge_breakdown_uses_pooled_counts_not_batch_means()
    test_calibration_caps_fail_closed_instead_of_silently_underdosing()
    test_reference_refresh_unions_molecules_without_duplicating_same_molecule()
    test_action_conditioned_reference_adds_exact_switch_with_shared_boundary()
    test_action_conditioned_reference_merges_new_row_for_existing_molecule()
    test_virtual_adamw_update_matches_real_optimizer_step()
    test_optimizer_parameter_groups_partition_action_gradient_ledger()
    test_inner_semantic_projection_cannot_erase_corrective_direction()
    test_gradient_cosine_is_bounded_and_marks_inactive_branches()
    test_registered_formal_v3_configuration_fails_closed_on_drift()
    test_dense_auxiliary_scale_preserves_sparse_mass_and_caps_dense_mass()
    print("[test_noise_corrected_direct_v3_trainer] PASS tests=22")


if __name__ == "__main__":
    main()

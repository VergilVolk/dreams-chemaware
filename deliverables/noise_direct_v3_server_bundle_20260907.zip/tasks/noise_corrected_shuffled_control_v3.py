"""Training-only causal shuffled control for noise direct-v3.

This module is deliberately separate from ``noise_corrected_action_routing_v3``.
Formal N/P/A4 routes hash the routing module, while shuffled controls are built
only after those routes have been frozen. Keeping the implementation here lets
an already completed route bundle remain provenance-valid when the training-only
control implementation is repaired.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


SHUFFLE_MATCHING_COLUMNS = (
    "supervision_kind",
    "source",
    "family",
    "recipe_id",
)


def source_family_shuffle_strata_report(
    actions: pd.DataFrame,
) -> dict[str, object]:
    """Audit formal shuffle feasibility without loading or copying spectra."""
    required = {
        "query_index", "action_id", "source", "family", "recipe_id",
        "supervision_kind",
    }
    if missing := required - set(actions.columns):
        raise KeyError(f"training action table misses {sorted(missing)}")
    cells = actions.groupby(
        list(SHUFFLE_MATCHING_COLUMNS), sort=True, dropna=False,
    ).agg(rows=("action_id", "size"), queries=("query_index", "nunique"))
    cross_query_rows = int(cells.loc[cells.queries.ge(2), "rows"].sum())
    fallback_rows = int(cells.loc[cells.queries.lt(2), "rows"].sum())
    legacy_columns = ["supervision_kind", "source", "recipe_id"]
    legacy = actions.groupby(
        legacy_columns, sort=True, dropna=False,
    ).agg(rows=("action_id", "size"), families=("family", "nunique"))
    collisions = legacy.loc[legacy.families.gt(1)]
    return {
        "matching_columns": list(SHUFFLE_MATCHING_COLUMNS),
        "strata": int(len(cells)),
        "rows": int(len(actions)),
        "cross_query_rows": cross_query_rows,
        "cross_query_fraction": (
            float(cross_query_rows / len(actions)) if len(actions) else 0.0
        ),
        "paired_control_fallback_rows": fallback_rows,
        "legacy_key_multi_family_strata": int(len(collisions)),
        "legacy_key_multi_family_rows": int(collisions.rows.sum()),
    }


def source_family_shuffled_action_bank(
    actions: pd.DataFrame,
    action_spectra: np.ndarray,
    control_spectra: np.ndarray,
    *,
    seed: int,
) -> tuple[np.ndarray, dict[str, object]]:
    """Build a chemistry-mismatched, exact-action-cell-matched control.

    Every target receives an action spectrum from a different query inside the
    same supervision/source/family/recipe cell. ``family`` is an independent
    part of the cell: in particular, an A4 ``recipe_id`` stores token and dose,
    while its family stores peak role and gradient-rank bin. Omitting family
    would therefore either mix distinct A4 semantics or fail on the formal
    ledger. A cell containing only one query falls back to the target's paired
    control spectrum.
    """
    required = {
        "query_index", "action_id", "source", "family", "recipe_id",
        "supervision_kind", "action_tensor_index",
    }
    if missing := required - set(actions.columns):
        raise KeyError(f"training action table misses {sorted(missing)}")
    indices = actions.action_tensor_index.to_numpy(np.int64)
    if (
        action_spectra.shape != control_spectra.shape
        or len(actions) != len(action_spectra)
        or not np.array_equal(indices, np.arange(len(actions), dtype=np.int64))
    ):
        raise RuntimeError("action/control tensor bank is not table-aligned")

    strata_report = source_family_shuffle_strata_report(actions)

    output = np.empty_like(action_spectra)
    rng = np.random.default_rng(int(seed))
    cross_query_rows = 0
    fallback_rows = 0
    strata = 0
    for key, block in actions.groupby(
        list(SHUFFLE_MATCHING_COLUMNS), sort=True, dropna=False,
    ):
        strata += 1
        observed = {
            tuple(map(str, values))
            for values in block[list(SHUFFLE_MATCHING_COLUMNS)].itertuples(
                index=False, name=None,
            )
        }
        if len(observed) != 1 or tuple(map(str, key)) not in observed:
            raise RuntimeError("shuffled exact action-cell grouping drifted")
        by_query = {
            int(query): values.sort_values("action_id", kind="stable")
            for query, values in block.groupby("query_index", sort=True)
        }
        queries = list(by_query)
        rng.shuffle(queries)
        if len(queries) < 2:
            own = by_query[queries[0]].action_tensor_index.to_numpy(np.int64)
            output[own] = control_spectra[own]
            fallback_rows += len(own)
            continue
        for position, query in enumerate(queries):
            donor_query = queries[(position + 1) % len(queries)]
            if donor_query == query:
                raise RuntimeError("shuffled action retained its own query")
            target = by_query[query].action_tensor_index.to_numpy(np.int64)
            donor = by_query[donor_query].action_tensor_index.to_numpy(np.int64)
            for offset, target_index in enumerate(target):
                output[target_index] = action_spectra[donor[offset % len(donor)]]
                cross_query_rows += 1
    if cross_query_rows + fallback_rows != len(actions) or not np.isfinite(output).all():
        raise RuntimeError("shuffled action control did not cover the tensor bank")
    if (
        cross_query_rows != strata_report["cross_query_rows"]
        or fallback_rows != strata_report["paired_control_fallback_rows"]
        or strata != strata_report["strata"]
    ):
        raise RuntimeError("shuffled tensor assignment differs from strata preflight")
    return output, {
        "strategy": (
            "supervision_source_family_exact_recipe_matched_"
            "cross_query_cyclic_shuffle"
        ),
        **strata_report,
        "dose_and_action_semantics_preserved": True,
        "family_semantics_preserved": True,
        "seed": int(seed),
        "true_action_row_reused_for_same_query": False,
    }

"""Parameter-update arbitration for direct noise fine-tuning.

The v3 trainer protects the corrective gradient before AdamW, but AdamW is a
non-linear map because it mixes the current gradient with historical first and
second moments.  Consequently a well-preserved action gradient can still leave
only a small action-attributable parameter update.  This module operates on
*virtual AdamW descent updates* and constructs a norm-neutral v4 candidate:

1. decompose the combined update into the risk-only counterfactual plus the
   action-attributable residual;
2. remove only a component of that residual that directly opposes the
   risk-only update;
3. amplify the remaining residual just enough to reach a registered minimum
   attributable fraction, subject to a hard gain cap; and
4. rescale the complete update to the original combined-update norm.

It does not define a teacher, distillation target, learning-rate increase or
extra optimizer dose.  The helper is intentionally pure and is not wired into
the running v3 experiment.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch


@dataclass(frozen=True)
class UpdateArbitrationResult:
    updates: list[torch.Tensor | None]
    action_gain: float
    norm_rescale: float
    original_update_norm: float
    final_update_norm: float
    original_attributable_fraction: float
    final_attributable_fraction: float
    action_risk_cosine_before: float | None
    action_risk_cosine_after: float | None
    target_reached: bool
    gain_cap_hit: bool


def _aligned(
    combined: list[torch.Tensor | None],
    risk: list[torch.Tensor | None],
) -> tuple[list[torch.Tensor | None], list[torch.Tensor | None]]:
    if len(combined) != len(risk):
        raise ValueError("combined and risk-only updates must align")
    combined_out: list[torch.Tensor | None] = []
    risk_out: list[torch.Tensor | None] = []
    for left, right in zip(combined, risk):
        if left is None and right is None:
            combined_out.append(None)
            risk_out.append(None)
            continue
        if left is None:
            raise ValueError("risk-only update exists where combined update is absent")
        if not torch.isfinite(left).all():
            raise ValueError("combined update contains non-finite values")
        if right is None:
            right = torch.zeros_like(left)
        if right.shape != left.shape or right.device != left.device:
            raise ValueError("combined and risk-only update tensors must align")
        if not torch.isfinite(right).all():
            raise ValueError("risk-only update contains non-finite values")
        combined_out.append(left.detach())
        risk_out.append(right.detach())
    if not any(value is not None for value in combined_out):
        raise ValueError("at least one optimizer update is required")
    return combined_out, risk_out


def _stats(
    left: list[torch.Tensor | None],
    right: list[torch.Tensor | None],
) -> tuple[float, float, float]:
    left_sq = right_sq = dot = 0.0
    for x, y in zip(left, right):
        if x is None or y is None:
            continue
        xf = x.float()
        yf = y.float()
        left_sq += float(torch.sum(xf * xf))
        right_sq += float(torch.sum(yf * yf))
        dot += float(torch.sum(xf * yf))
    return left_sq, right_sq, dot


def _cosine(left_sq: float, right_sq: float, dot: float) -> float | None:
    if left_sq <= 0 or right_sq <= 0:
        return None
    return float(dot / np.sqrt(left_sq * right_sq))


def _fraction(action_sq: float, risk_sq: float, dot: float, gain: float) -> float:
    action_norm = float(gain) * np.sqrt(max(action_sq, 0.0))
    combined_sq = risk_sq + float(gain) ** 2 * action_sq + 2 * float(gain) * dot
    combined_norm = np.sqrt(max(combined_sq, np.finfo(float).eps))
    return float(action_norm / combined_norm)


def arbitrate_optimizer_updates(
    combined_updates: list[torch.Tensor | None],
    risk_only_updates: list[torch.Tensor | None],
    *,
    minimum_attributable_fraction: float,
    maximum_action_gain: float = 2.0,
    norm_neutral: bool = True,
    materialize_updates: bool = True,
) -> UpdateArbitrationResult:
    """Return a bounded optimizer-space action restoration candidate.

    ``combined_updates`` and ``risk_only_updates`` are descent directions
    (parameter value before minus parameter value after) evaluated from the
    same AdamW state.  The returned tensors have the same layout and dtype.
    """
    if not 0 < minimum_attributable_fraction < 1:
        raise ValueError("minimum attributable fraction must be in (0, 1)")
    if maximum_action_gain < 1:
        raise ValueError("maximum action gain must be at least one")
    combined, risk = _aligned(combined_updates, risk_only_updates)
    action = [
        None if left is None else left - right
        for left, right in zip(combined, risk)
    ]
    combined_sq, _, _ = _stats(combined, combined)
    action_sq, risk_sq, action_risk_dot = _stats(action, risk)
    if combined_sq <= 0 or action_sq <= 0:
        raise ValueError("combined and action-attributable updates must be non-zero")
    original_fraction = float(np.sqrt(action_sq / combined_sq))
    original_cosine = _cosine(action_sq, risk_sq, action_risk_dot)
    if original_fraction >= minimum_attributable_fraction:
        return UpdateArbitrationResult(
            updates=(
                [None if value is None else value.clone() for value in combined]
                if materialize_updates else []
            ),
            action_gain=1.0,
            norm_rescale=1.0,
            original_update_norm=float(np.sqrt(combined_sq)),
            final_update_norm=float(np.sqrt(combined_sq)),
            original_attributable_fraction=original_fraction,
            final_attributable_fraction=original_fraction,
            action_risk_cosine_before=original_cosine,
            action_risk_cosine_after=original_cosine,
            target_reached=True,
            gain_cap_hit=False,
        )

    # Only remove direct opposition to the protective counterfactual.  This is
    # the update-space analogue of v3's gradient-space PCGrad and cannot reduce
    # the first-order protective descent component.
    projection = action_risk_dot / risk_sq if risk_sq > 0 and action_risk_dot < 0 else 0.0
    safe_action = [
        None if left is None else left - float(projection) * right
        for left, right in zip(action, risk)
    ]
    safe_action_sq, risk_sq, safe_dot = _stats(safe_action, risk)
    if safe_action_sq <= 0:
        raise ValueError("action-attributable update vanished after risk projection")

    target = float(minimum_attributable_fraction)
    high = float(maximum_action_gain)
    if _fraction(safe_action_sq, risk_sq, safe_dot, high) < target:
        gain = high
        cap_hit = True
    else:
        low = 1.0
        for _ in range(64):
            middle = 0.5 * (low + high)
            if _fraction(safe_action_sq, risk_sq, safe_dot, middle) >= target:
                high = middle
            else:
                low = middle
        gain = high
        cap_hit = bool(np.isclose(gain, maximum_action_gain))

    candidate_sq = risk_sq + gain**2 * safe_action_sq + 2 * gain * safe_dot
    rescale = float(np.sqrt(combined_sq / candidate_sq)) if norm_neutral else 1.0
    output = (
        [
            None if left is None else (
                right + float(gain) * left
            ).mul(rescale).to(dtype=original.dtype)
            for left, right, original in zip(safe_action, risk, combined)
        ]
        if materialize_updates else []
    )
    final_sq = combined_sq if norm_neutral else candidate_sq
    # A common rescale leaves the attributable fraction unchanged.
    final_fraction = _fraction(safe_action_sq, risk_sq, safe_dot, gain)
    safe_cosine = _cosine(safe_action_sq, risk_sq, safe_dot)
    return UpdateArbitrationResult(
        updates=output,
        action_gain=float(gain),
        norm_rescale=rescale,
        original_update_norm=float(np.sqrt(combined_sq)),
        final_update_norm=float(np.sqrt(final_sq)),
        original_attributable_fraction=original_fraction,
        final_attributable_fraction=final_fraction,
        action_risk_cosine_before=original_cosine,
        action_risk_cosine_after=safe_cosine,
        target_reached=bool(final_fraction >= target - 1e-10),
        gain_cap_hit=cap_hit,
    )

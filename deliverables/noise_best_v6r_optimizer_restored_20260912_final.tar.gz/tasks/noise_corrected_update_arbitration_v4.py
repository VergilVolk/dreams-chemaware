"""Parameter-update arbitration for direct noise fine-tuning.

The v3 trainer protects the corrective gradient before AdamW, but AdamW is a
non-linear map because it mixes the current gradient with historical first and
second moments.  Consequently a well-preserved action gradient can still leave
only a small action-attributable parameter update.  This module operates on
*virtual AdamW descent updates* and constructs a norm-neutral v4 candidate:

1. decompose the combined update into the risk-only counterfactual plus the
   action-attributable residual;
2. remove only a component of that residual that directly opposes the
   risk-only update;
3. amplify the remaining residual just enough to reach a registered minimum
   attributable fraction, subject to a hard gain cap; and
4. rescale the complete update to the original combined-update norm.

It does not define a teacher, distillation target, learning-rate increase or
extra optimizer dose.  The v6-restored contract applies the group-wise result
after the ordinary AdamW step, so AdamW state still advances from the real
combined gradient while the same-step parameter displacement retains the
registered action signal.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch


@dataclass(frozen=True)
class UpdateArbitrationResult:
    updates: list[torch.Tensor | None]
    action_gain: float
    norm_rescale: float
    original_update_norm: float
    final_update_norm: float
    original_attributable_fraction: float
    final_attributable_fraction: float
    action_risk_cosine_before: float | None
    action_risk_cosine_after: float | None
    target_reached: bool
    gain_cap_hit: bool
    risk_component_before: float
    risk_component_after: float
    risk_component_retention: float
    risk_constraint_active: bool


@dataclass(frozen=True)
class GroupwiseUpdateArbitrationResult:
    updates: list[torch.Tensor | None]
    parameter_groups: dict[str, UpdateArbitrationResult]
    original_update_norm: float
    final_update_norm: float
    all_groups_target_reached: bool
    minimum_group_risk_component_retention: float


def _aligned(
    combined: list[torch.Tensor | None],
    risk: list[torch.Tensor | None],
) -> tuple[list[torch.Tensor | None], list[torch.Tensor | None]]:
    if len(combined) != len(risk):
        raise ValueError("combined and risk-only updates must align")
    combined_out: list[torch.Tensor | None] = []
    risk_out: list[torch.Tensor | None] = []
    for left, right in zip(combined, risk):
        if left is None and right is None:
            combined_out.append(None)
            risk_out.append(None)
            continue
        if left is None:
            raise ValueError("risk-only update exists where combined update is absent")
        if not torch.isfinite(left).all():
            raise ValueError("combined update contains non-finite values")
        if right is None:
            right = torch.zeros_like(left)
        if right.shape != left.shape or right.device != left.device:
            raise ValueError("combined and risk-only update tensors must align")
        if not torch.isfinite(right).all():
            raise ValueError("risk-only update contains non-finite values")
        combined_out.append(left.detach())
        risk_out.append(right.detach())
    if not any(value is not None for value in combined_out):
        raise ValueError("at least one optimizer update is required")
    return combined_out, risk_out


def _stats(
    left: list[torch.Tensor | None],
    right: list[torch.Tensor | None],
) -> tuple[float, float, float]:
    contributions: list[torch.Tensor] = []
    for x, y in zip(left, right):
        if x is None or y is None:
            continue
        xf = x.float()
        yf = y.float()
        contributions.append(torch.stack((
            torch.sum(xf * xf),
            torch.sum(yf * yf),
            torch.sum(xf * yf),
        )).double())
    if not contributions:
        return 0.0, 0.0, 0.0
    # One device-to-host synchronization per complete parameter group.  The
    # old per-tensor float conversions were acceptable for 64 audit steps but
    # would dominate an exhaustive 14,032-step formal restoration.
    totals = torch.stack(contributions).sum(dim=0).cpu().tolist()
    return tuple(map(float, totals))


def _cosine(left_sq: float, right_sq: float, dot: float) -> float | None:
    if left_sq <= 0 or right_sq <= 0:
        return None
    return float(dot / np.sqrt(left_sq * right_sq))


def _candidate_stats(
    *,
    original_combined_sq: float,
    action_sq: float,
    risk_sq: float,
    dot: float,
    gain: float,
    norm_neutral: bool,
) -> tuple[float, float, float, float]:
    """Return rescale, final norm, true counterfactual fraction and risk dot.

    The action-attributable quantity used by the trainer is the materialized
    update minus the *unscaled* risk-only AdamW counterfactual.  When the
    candidate is made norm neutral, merely reporting ``gain * action`` would
    omit the ``(rescale - 1) * risk`` term and overstate what the signal gate
    will observe.  This helper keeps the optimizer-space design and the gate on
    exactly the same definition.
    """
    gain = float(gain)
    candidate_sq = risk_sq + gain**2 * action_sq + 2 * gain * dot
    if candidate_sq <= 0:
        raise ValueError("optimizer restoration candidate has zero norm")
    rescale = (
        float(np.sqrt(original_combined_sq / candidate_sq))
        if norm_neutral else 1.0
    )
    final_sq = rescale**2 * candidate_sq
    risk_coefficient = rescale - 1.0
    action_coefficient = rescale * gain
    attributable_sq = (
        risk_coefficient**2 * risk_sq
        + action_coefficient**2 * action_sq
        + 2 * risk_coefficient * action_coefficient * dot
    )
    fraction = float(np.sqrt(max(attributable_sq, 0.0) / final_sq))
    risk_component = float(rescale * (risk_sq + gain * dot))
    return rescale, float(np.sqrt(final_sq)), fraction, risk_component


def arbitrate_optimizer_updates(
    combined_updates: list[torch.Tensor | None],
    risk_only_updates: list[torch.Tensor | None],
    *,
    minimum_attributable_fraction: float,
    maximum_action_gain: float = 2.0,
    norm_neutral: bool = True,
    minimum_risk_component_retention: float = 0.0,
    materialize_updates: bool = True,
) -> UpdateArbitrationResult:
    """Return a bounded optimizer-space action restoration candidate.

    ``combined_updates`` and ``risk_only_updates`` are descent directions
    (parameter value before minus parameter value after) evaluated from the
    same AdamW state.  The returned tensors have the same layout and dtype.
    """
    if not 0 < minimum_attributable_fraction < 1:
        raise ValueError("minimum attributable fraction must be in (0, 1)")
    if maximum_action_gain < 1:
        raise ValueError("maximum action gain must be at least one")
    if not 0 <= minimum_risk_component_retention <= 1:
        raise ValueError("minimum risk-component retention must be in [0, 1]")
    combined, risk = _aligned(combined_updates, risk_only_updates)
    action = [
        None if left is None else left - right
        for left, right in zip(combined, risk)
    ]
    combined_sq, _, _ = _stats(combined, combined)
    action_sq, risk_sq, action_risk_dot = _stats(action, risk)
    if combined_sq <= 0 or action_sq <= 0:
        raise ValueError("combined and action-attributable updates must be non-zero")
    original_fraction = float(np.sqrt(action_sq / combined_sq))
    original_cosine = _cosine(action_sq, risk_sq, action_risk_dot)
    original_risk_component = float(risk_sq + action_risk_dot)
    required_risk_component = float(
        minimum_risk_component_retention * risk_sq
    )
    risk_tolerance = 1e-10 * max(1.0, abs(required_risk_component))
    if (
        original_fraction >= minimum_attributable_fraction
        and original_risk_component >= required_risk_component - risk_tolerance
    ):
        return UpdateArbitrationResult(
            updates=(
                [None if value is None else value.clone() for value in combined]
                if materialize_updates else []
            ),
            action_gain=1.0,
            norm_rescale=1.0,
            original_update_norm=float(np.sqrt(combined_sq)),
            final_update_norm=float(np.sqrt(combined_sq)),
            original_attributable_fraction=original_fraction,
            final_attributable_fraction=original_fraction,
            action_risk_cosine_before=original_cosine,
            action_risk_cosine_after=original_cosine,
            target_reached=True,
            gain_cap_hit=False,
            risk_component_before=original_risk_component,
            risk_component_after=original_risk_component,
            risk_component_retention=(
                float(original_risk_component / risk_sq)
                if risk_sq > 0 else 1.0
            ),
            risk_constraint_active=False,
        )

    # Only remove direct opposition to the protective counterfactual.  This is
    # the update-space analogue of v3's gradient-space PCGrad and cannot reduce
    # the first-order protective descent component.
    projection = action_risk_dot / risk_sq if risk_sq > 0 and action_risk_dot < 0 else 0.0
    safe_action = [
        None if left is None else left - float(projection) * right
        for left, right in zip(action, risk)
    ]
    safe_action_sq, risk_sq, safe_dot = _stats(safe_action, risk)
    if safe_action_sq <= 0:
        raise ValueError("action-attributable update vanished after risk projection")

    target = float(minimum_attributable_fraction)
    high = float(maximum_action_gain)

    def candidate_stats(gain: float) -> tuple[float, float, float, float]:
        return _candidate_stats(
            original_combined_sq=combined_sq,
            action_sq=safe_action_sq,
            risk_sq=risk_sq,
            dot=safe_dot,
            gain=gain,
            norm_neutral=norm_neutral,
        )

    if candidate_stats(high)[2] < target:
        gain = high
        cap_hit = True
    else:
        low = 1.0
        for _ in range(64):
            middle = 0.5 * (low + high)
            if candidate_stats(middle)[2] >= target:
                high = middle
            else:
                low = middle
        gain = high
        cap_hit = bool(np.isclose(gain, maximum_action_gain))

    # A registered restoration may reserve a minimum fraction of the risk-only
    # AdamW descent projection.  Exact preservation would make any
    # norm-neutral amplification of an orthogonal action mathematically
    # impossible, so the caller chooses the explicit floor (V6R uses 0.90).
    # Gain one is the original combined update for non-conflicting residuals;
    # if the requested gain crosses the floor, retain the largest safe gain.
    rescale, final_norm, final_fraction, final_risk_component = candidate_stats(gain)
    risk_constraint_active = False
    if final_risk_component < required_risk_component - risk_tolerance:
        base = candidate_stats(1.0)
        if base[3] < required_risk_component - risk_tolerance:
            # Extremely pathological conflict: the risk-projected path itself
            # is unsafe after norm neutralization.  Preserve the exact original
            # update instead of inventing a weaker protective step.
            return UpdateArbitrationResult(
                updates=(
                    [None if value is None else value.clone() for value in combined]
                    if materialize_updates else []
                ),
                action_gain=1.0,
                norm_rescale=1.0,
                original_update_norm=float(np.sqrt(combined_sq)),
                final_update_norm=float(np.sqrt(combined_sq)),
                original_attributable_fraction=original_fraction,
                final_attributable_fraction=original_fraction,
                action_risk_cosine_before=original_cosine,
                action_risk_cosine_after=original_cosine,
                target_reached=False,
                gain_cap_hit=False,
                risk_component_before=original_risk_component,
                risk_component_after=original_risk_component,
                risk_component_retention=(
                    float(original_risk_component / risk_sq)
                    if risk_sq > 0 else 1.0
                ),
                risk_constraint_active=True,
            )
        low, high = 1.0, gain
        for _ in range(64):
            middle = 0.5 * (low + high)
            if candidate_stats(middle)[3] >= required_risk_component - risk_tolerance:
                low = middle
            else:
                high = middle
        gain = low
        rescale, final_norm, final_fraction, final_risk_component = candidate_stats(gain)
        risk_constraint_active = True
    output = (
        [
            None if left is None else (
                right + float(gain) * left
            ).mul(rescale).to(dtype=original.dtype)
            for left, right, original in zip(safe_action, risk, combined)
        ]
        if materialize_updates else []
    )
    safe_cosine = _cosine(safe_action_sq, risk_sq, safe_dot)
    return UpdateArbitrationResult(
        updates=output,
        action_gain=float(gain),
        norm_rescale=rescale,
        original_update_norm=float(np.sqrt(combined_sq)),
        final_update_norm=final_norm,
        original_attributable_fraction=original_fraction,
        final_attributable_fraction=final_fraction,
        action_risk_cosine_before=original_cosine,
        action_risk_cosine_after=safe_cosine,
        target_reached=bool(final_fraction >= target - 1e-10),
        gain_cap_hit=cap_hit,
        risk_component_before=original_risk_component,
        risk_component_after=final_risk_component,
        risk_component_retention=(
            float(final_risk_component / risk_sq) if risk_sq > 0 else 1.0
        ),
        risk_constraint_active=risk_constraint_active,
    )


def arbitrate_optimizer_updates_by_group(
    combined_updates: list[torch.Tensor | None],
    risk_only_updates: list[torch.Tensor | None],
    parameter_group_positions: dict[str, list[int]],
    *,
    minimum_attributable_fraction: float,
    maximum_action_gain: float,
    minimum_risk_component_retention: float,
    materialize_updates: bool = True,
) -> GroupwiseUpdateArbitrationResult:
    """Restore action attribution independently in every optimizer group.

    Head and backbone use different learning rates and AdamW moments.  A single
    global gain can therefore hide a weak backbone behind a healthy projection
    head.  Per-group norm neutrality preserves both registered update budgets,
    while the complete partition also preserves the global update norm.
    """
    if len(combined_updates) != len(risk_only_updates):
        raise ValueError("combined and risk-only update layouts must align")
    expected = set(range(len(combined_updates)))
    observed: list[int] = [
        int(position)
        for positions in parameter_group_positions.values()
        for position in positions
    ]
    if not parameter_group_positions or set(observed) != expected or len(observed) != len(expected):
        raise ValueError("parameter groups must partition every update exactly once")

    output: list[torch.Tensor | None] = [None] * len(combined_updates)
    reports: dict[str, UpdateArbitrationResult] = {}
    for name in sorted(parameter_group_positions):
        positions = list(map(int, parameter_group_positions[name]))
        report = arbitrate_optimizer_updates(
            [combined_updates[position] for position in positions],
            [risk_only_updates[position] for position in positions],
            minimum_attributable_fraction=minimum_attributable_fraction,
            maximum_action_gain=maximum_action_gain,
            norm_neutral=True,
            minimum_risk_component_retention=minimum_risk_component_retention,
            materialize_updates=materialize_updates,
        )
        reports[name] = report
        if materialize_updates:
            for position, update in zip(positions, report.updates):
                output[position] = update

    original_norm = float(np.sqrt(sum(
        report.original_update_norm**2 for report in reports.values()
    )))
    final_norm = float(np.sqrt(sum(
        report.final_update_norm**2 for report in reports.values()
    )))
    if not np.isclose(original_norm, final_norm, rtol=1e-6, atol=1e-10):
        raise RuntimeError("groupwise restoration changed the global update norm")
    return GroupwiseUpdateArbitrationResult(
        updates=output if materialize_updates else [],
        parameter_groups=reports,
        original_update_norm=original_norm,
        final_update_norm=final_norm,
        all_groups_target_reached=all(
            report.target_reached for report in reports.values()
        ),
        minimum_group_risk_component_retention=min(
            report.risk_component_retention for report in reports.values()
        ),
    )


@torch.no_grad()
def materialize_descent_updates_(
    parameters: list[torch.nn.Parameter],
    parameters_before_step: list[torch.Tensor],
    descent_updates: list[torch.Tensor | None],
) -> None:
    """Overwrite only parameter values with a registered descent direction.

    AdamW moments have already advanced under the real combined gradient.  This
    function changes the current parameter displacement, not optimizer state,
    learning rates, weight decay, gradient dose or the next step number.
    """
    if not (
        len(parameters) == len(parameters_before_step) == len(descent_updates)
    ):
        raise ValueError("parameter materialization layouts must align")
    for parameter, before, update in zip(
        parameters, parameters_before_step, descent_updates,
    ):
        if before.shape != parameter.shape or before.device != parameter.device:
            raise ValueError("parameter snapshot does not align with live parameter")
        if update is None:
            parameter.copy_(before)
            continue
        if update.shape != parameter.shape or update.device != parameter.device:
            raise ValueError("descent update does not align with live parameter")
        if not torch.isfinite(update).all():
            raise ValueError("descent update contains non-finite values")
        parameter.copy_(before - update.to(dtype=parameter.dtype))
